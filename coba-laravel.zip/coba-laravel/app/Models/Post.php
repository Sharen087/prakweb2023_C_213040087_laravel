<?php 

namespace App\Models;

// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;

class Post 
{
    private static $blog_posts = [
        [
            "title" => "Judul tulisan Pertama",
            "slug" => "judul-tulisan-pertama",
            "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore ducimus dolores perferendis maxime autem est, libero fugiat, quod vel ipsa totam tenetur odio nihil nam fugit impedit, mollitia reprehenderit. Eveniet."
        ],
        [
            "title" => "Judul tulisan Kedua",
            "slug" => "judul-tulisan-kedua",
            "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore ducimus dolores perferendis maxime autem est, libero fugiat, quod vel ipsa totam tenetur odio nihil nam fugit impedit, mollitia reprehenderit. Eveniet."
        ]
        ];

        public static function all()
        {
            return self::$blog_posts;
        }

        public static function find($slug)
        {
            $posts = self::$blog_posts;
            $post = [];
            foreach($posts as $p) {
                if($p["slug"] === $slug) {
                    $post = $p;
                }
            }

            return $post;
        }
}

?>