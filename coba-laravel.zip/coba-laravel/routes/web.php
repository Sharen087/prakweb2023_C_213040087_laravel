<?php

use App\Models\Post;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;


// use App\Models\Post;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//untuk mengubah tampilan keseluruhan 
Route::get('/', function () {

    //untuk mengganti tampilan
    return view('home');
});

Route::get('/', function () {
    return view('about', [
        "name" => "Sharen",
        "email" => "palambasharen15@gmail.com",
        "image" => "shrn.jpg"
    ]);
});

Route::get('/posts', function () {
    return view('posts', [
        "title" => "Posts",
        "posts" => Post::all()
    ]);
});

Route::get('/posts', [PostController::class, 'index']);


Route::get('/posts/{slug}', function ($slug) {

Route::get('/posts/{slug', [PosController::class, 'show']);
    // return view('post', [
    //     "title" => "Single Post",
    //     "post" => Post::find($slug)
    // ]);

});


    // $new_post = [];
    // foreach($posts as $post) {
    //     if($post["slug"] == $slug) {
    //         $new_post = $post;
    //     }
    // }

    // $posts = [
    //     [
    //         "title" => "Judul tulisan Pertama",
    //         "slug" => "judul-tulisan-pertama",
    //         "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore ducimus dolores perferendis maxime autem est, libero fugiat, quod vel ipsa totam tenetur odio nihil nam fugit impedit, mollitia reprehenderit. Eveniet."
    //     ],
    //     [
    //         "title" => "Judul tulisan Kedua",
    //         "slug" => "judul-tulisan-kedua",
    //         "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Inventore ducimus dolores perferendis maxime autem est, libero fugiat, quod vel ipsa totam tenetur odio nihil nam fugit impedit, mollitia reprehenderit. Eveniet."
    //     ]
    // ]



